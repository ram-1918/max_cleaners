export default function RegisterPage(){
    return (
        <form>Register</form>
    )
}