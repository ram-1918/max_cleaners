import PageRoutes from "./pageroutes/PageRoutes";

export default function App() {
  return <PageRoutes />;
}

// https://github.com/airbnb/javascript/tree/master/react